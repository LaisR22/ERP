CREATE TABLE `eventos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`veiculoId` int NOT NULL,
	`motoristaId` int,
	`tipo` enum('BLOQUEIO','ALERTA','DESBLOQUEIO') NOT NULL,
	`descricao` text,
	`ppm` float,
	`dataHora` timestamp NOT NULL DEFAULT (now()),
	`criadoEm` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `eventos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `leiturasSensor` (
	`id` int AUTO_INCREMENT NOT NULL,
	`veiculoId` int NOT NULL,
	`motoristaId` int,
	`ppm` float NOT NULL,
	`status` enum('LIBERADO','ALERTA','BLOQUEADO') NOT NULL,
	`bloqueado` boolean NOT NULL DEFAULT false,
	`dataHora` timestamp NOT NULL DEFAULT (now()),
	`criadoEm` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `leiturasSensor_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `motoristas` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nome` varchar(255) NOT NULL,
	`cpf` varchar(11) NOT NULL,
	`email` varchar(255),
	`telefone` varchar(20),
	`ativo` boolean NOT NULL DEFAULT true,
	`criadoEm` timestamp NOT NULL DEFAULT (now()),
	`atualizadoEm` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `motoristas_id` PRIMARY KEY(`id`),
	CONSTRAINT `motoristas_cpf_unique` UNIQUE(`cpf`)
);
--> statement-breakpoint
CREATE TABLE `veiculos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`placa` varchar(10) NOT NULL,
	`marca` varchar(100),
	`modelo` varchar(100),
	`ano` int,
	`cor` varchar(50),
	`ativo` boolean NOT NULL DEFAULT true,
	`criadoEm` timestamp NOT NULL DEFAULT (now()),
	`atualizadoEm` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `veiculos_id` PRIMARY KEY(`id`),
	CONSTRAINT `veiculos_placa_unique` UNIQUE(`placa`)
);
