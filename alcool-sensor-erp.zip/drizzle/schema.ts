import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, float, boolean } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Tabela de Motoristas
 * Armazena informações dos condutores que usam os veículos
 */
export const motoristas = mysqlTable("motoristas", {
  id: int("id").autoincrement().primaryKey(),
  nome: varchar("nome", { length: 255 }).notNull(),
  cpf: varchar("cpf", { length: 11 }).notNull().unique(),
  email: varchar("email", { length: 255 }),
  telefone: varchar("telefone", { length: 20 }),
  ativo: boolean("ativo").default(true).notNull(),
  criadoEm: timestamp("criadoEm").defaultNow().notNull(),
  atualizadoEm: timestamp("atualizadoEm").defaultNow().onUpdateNow().notNull(),
});

export type Motorista = typeof motoristas.$inferSelect;
export type InsertMotorista = typeof motoristas.$inferInsert;

/**
 * Tabela de Veículos
 * Armazena informações dos veículos monitorados
 */
export const veiculos = mysqlTable("veiculos", {
  id: int("id").autoincrement().primaryKey(),
  placa: varchar("placa", { length: 10 }).notNull().unique(),
  marca: varchar("marca", { length: 100 }),
  modelo: varchar("modelo", { length: 100 }),
  ano: int("ano"),
  cor: varchar("cor", { length: 50 }),
  ativo: boolean("ativo").default(true).notNull(),
  criadoEm: timestamp("criadoEm").defaultNow().notNull(),
  atualizadoEm: timestamp("atualizadoEm").defaultNow().onUpdateNow().notNull(),
});

export type Veiculo = typeof veiculos.$inferSelect;
export type InsertVeiculo = typeof veiculos.$inferInsert;

/**
 * Tabela de Leituras do Sensor
 * Armazena as leituras de álcool capturadas pelo sensor ESP32
 * Limite de bloqueio: 300 ppm
 */
export const leiturasSensor = mysqlTable("leiturasSensor", {
  id: int("id").autoincrement().primaryKey(),
  veiculoId: int("veiculoId").notNull(),
  motoristaId: int("motoristaId"),
  ppm: float("ppm").notNull(),
  status: mysqlEnum("status", ["LIBERADO", "ALERTA", "BLOQUEADO"]).notNull(),
  bloqueado: boolean("bloqueado").default(false).notNull(),
  dataHora: timestamp("dataHora").defaultNow().notNull(),
  criadoEm: timestamp("criadoEm").defaultNow().notNull(),
});

export type LeituraSensor = typeof leiturasSensor.$inferSelect;
export type InsertLeituraSensor = typeof leiturasSensor.$inferInsert;

/**
 * Tabela de Eventos
 * Registra eventos importantes como bloqueios e alertas
 */
export const eventos = mysqlTable("eventos", {
  id: int("id").autoincrement().primaryKey(),
  veiculoId: int("veiculoId").notNull(),
  motoristaId: int("motoristaId"),
  tipo: mysqlEnum("tipo", ["BLOQUEIO", "ALERTA", "DESBLOQUEIO"]).notNull(),
  descricao: text("descricao"),
  ppm: float("ppm"),
  dataHora: timestamp("dataHora").defaultNow().notNull(),
  criadoEm: timestamp("criadoEm").defaultNow().notNull(),
});

export type Evento = typeof eventos.$inferSelect;
export type InsertEvento = typeof eventos.$inferInsert;

/**
 * Relações entre tabelas
 */
export const motoristasRelations = relations(motoristas, ({ many }) => ({
  leituras: many(leiturasSensor),
  eventos: many(eventos),
}));

export const veiculosRelations = relations(veiculos, ({ many }) => ({
  leituras: many(leiturasSensor),
  eventos: many(eventos),
}));

export const leiturasSensorRelations = relations(leiturasSensor, ({ one }) => ({
  veiculo: one(veiculos, {
    fields: [leiturasSensor.veiculoId],
    references: [veiculos.id],
  }),
  motorista: one(motoristas, {
    fields: [leiturasSensor.motoristaId],
    references: [motoristas.id],
  }),
}));

export const eventosRelations = relations(eventos, ({ one }) => ({
  veiculo: one(veiculos, {
    fields: [eventos.veiculoId],
    references: [veiculos.id],
  }),
  motorista: one(motoristas, {
    fields: [eventos.motoristaId],
    references: [motoristas.id],
  }),
}));