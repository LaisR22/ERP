/**
 * Script de Simulação de Dados do Sensor ESP32
 * Envia leituras de álcool simuladas para a API a cada 10 segundos
 * 
 * Uso: node mockData.mjs
 */

import fetch from 'node-fetch';

const API_URL = process.env.API_URL || 'http://localhost:3000/api/trpc';
const INTERVALO = process.env.INTERVALO || 10000; // 10 segundos

// Dados simulados de veículos
const VEICULOS = [
  { id: 1, placa: 'ABC-1234', marca: 'Toyota', modelo: 'Corolla' },
  { id: 2, placa: 'XYZ-5678', marca: 'Honda', modelo: 'Civic' },
  { id: 3, placa: 'DEF-9012', marca: 'Volkswagen', modelo: 'Gol' },
];

// Dados simulados de motoristas
const MOTORISTAS = [
  { id: 1, nome: 'João Silva' },
  { id: 2, nome: 'Maria Santos' },
  { id: 3, nome: 'Carlos Oliveira' },
];

/**
 * Gera um valor de PPM aleatório
 * 70% de chance: LIBERADO (0-210 ppm)
 * 20% de chance: ALERTA (210-300 ppm)
 * 10% de chance: BLOQUEADO (300+ ppm)
 */
function gerarPPM() {
  const random = Math.random();

  if (random < 0.7) {
    // LIBERADO: 0-210 ppm
    return Math.floor(Math.random() * 210);
  } else if (random < 0.9) {
    // ALERTA: 210-300 ppm
    return Math.floor(210 + Math.random() * 90);
  } else {
    // BLOQUEADO: 300+ ppm
    return Math.floor(300 + Math.random() * 150);
  }
}

/**
 * Envia uma leitura para a API
 */
async function enviarLeitura() {
  try {
    const veiculo = VEICULOS[Math.floor(Math.random() * VEICULOS.length)];
    const motorista = MOTORISTAS[Math.floor(Math.random() * MOTORISTAS.length)];
    const ppm = gerarPPM();

    const payload = {
      veiculoId: veiculo.id,
      motoristaId: motorista.id,
      ppm: ppm,
    };

    // Usar fetch para chamar a API tRPC
    const response = await fetch(`${API_URL}/leituras.criar`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        json: payload,
      }),
    });

    if (response.ok) {
      const data = await response.json();
      const status = ppm > 300 ? 'BLOQUEADO' : ppm > 210 ? 'ALERTA' : 'LIBERADO';
      console.log(
        `[${new Date().toLocaleTimeString('pt-BR')}] ✓ Enviado: ${veiculo.placa} - ${motorista.nome} - ${ppm.toFixed(1)}ppm (${status})`
      );
    } else {
      console.error(`[${new Date().toLocaleTimeString('pt-BR')}] ✗ Erro na API:`, response.statusText);
    }
  } catch (error) {
    console.error(`[${new Date().toLocaleTimeString('pt-BR')}] ✗ Erro ao enviar leitura:`, error.message);
  }
}

/**
 * Inicia o envio periódico de leituras
 */
async function iniciarSimulacao() {
  console.log(`🚀 Iniciando simulação de sensor ESP32`);
  console.log(`📡 API URL: ${API_URL}`);
  console.log(`⏱️  Intervalo: ${INTERVALO}ms (${(INTERVALO / 1000).toFixed(1)}s)`);
  console.log(`🚗 Veículos: ${VEICULOS.map((v) => v.placa).join(', ')}`);
  console.log(`👥 Motoristas: ${MOTORISTAS.map((m) => m.nome).join(', ')}`);
  console.log(`\n📊 Iniciando envio de leituras...\n`);

  // Enviar primeira leitura imediatamente
  await enviarLeitura();

  // Depois enviar a cada intervalo
  setInterval(enviarLeitura, INTERVALO);
}

// Iniciar simulação
iniciarSimulacao().catch(console.error);

// Tratamento de sinais para encerramento gracioso
process.on('SIGINT', () => {
  console.log('\n\n🛑 Simulação encerrada');
  process.exit(0);
});
