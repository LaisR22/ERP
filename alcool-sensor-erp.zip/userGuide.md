# Guia do Usuário - ERP/Dashboard Sensor de Álcool no Volante

## Informações Gerais

**Website:** Disponível em produção após deploy (veja instruções de publicação)

**Propósito:** Sistema completo para monitorar em tempo real os níveis de álcool em veículos, gerenciar motoristas e gerar relatórios detalhados.

**Acesso:** Login obrigatório via Manus OAuth. Todos os usuários têm acesso ao dashboard após autenticação.

---

## Powered by Manus

**Stack Tecnológico:**
- **Frontend:** React 19 + TypeScript + TailwindCSS 4 + Recharts (gráficos interativos)
- **Backend:** Node.js + Express + tRPC (type-safe RPC)
- **Banco de Dados:** MySQL com Drizzle ORM
- **Autenticação:** Manus OAuth integrado
- **Deployment:** Auto-scaling infrastructure com global CDN

---

## Usando Seu Website

### 1. Dashboard - Monitoramento em Tempo Real

Após fazer login, você será redirecionado para o **Dashboard** onde pode:

- **Visualizar Cards de Resumo:** Veja "Total de Leituras", "Bloqueios", "Média PPM" e "Veículos Ativos" em tempo real
- **Acompanhar Gráficos:** O gráfico "Histórico de Leituras (PPM)" mostra as últimas 20 leituras com linha contínua
- **Verificar Distribuição:** O gráfico "Distribuição de Status" exibe quantas leituras foram Liberadas, Alertas ou Bloqueadas
- **Consultar Últimas Leituras:** Role pela tabela das 10 leituras mais recentes com status colorido (verde=seguro, amarelo=alerta, vermelho=bloqueio)

O dashboard atualiza automaticamente a cada 5 segundos.

### 2. Veículos - Gerenciamento de Frotas

Clique em "Veículos" no menu para:

- **Visualizar Tabela:** Veja todos os veículos cadastrados com placa, marca, modelo, ano, cor e status
- **Adicionar Novo Veículo:** Clique no botão "Novo Veículo" (funcionalidade para futuras expansões)
- **Acompanhar Status:** Cada veículo mostra um indicador verde (ativo) e data da última atualização
- **Ver Resumo:** Cards no final da página mostram "Total de Veículos", "Veículos Ativos" e "Última Atualização"

### 3. Motoristas - Histórico de Condutores

Clique em "Motoristas" no menu para:

- **Consultar Lista:** Veja todos os motoristas com nome, CPF formatado, email, telefone e data de cadastro
- **Adicionar Novo Motorista:** Clique em "Novo Motorista" (funcionalidade para futuras expansões)
- **Acompanhar Contatos:** Ícones indicam se motorista tem email ou telefone cadastrado
- **Ver Estatísticas:** Cards mostram "Total de Motoristas", "Motoristas Ativos" e "Com Email"

### 4. Relatórios - Análise Detalhada

Clique em "Relatórios" no menu para:

- **Filtrar por Veículo:** Use o dropdown "Veículo" para selecionar um veículo específico ou "Todos os veículos"
- **Exportar Dados:** Clique em "Exportar CSV" para baixar um arquivo com todas as leituras em formato CSV
- **Visualizar Gráficos:** O gráfico "Histórico de Leituras" mostra tendência de PPM, e "Distribuição por Status" exibe proporções
- **Consultar Detalhes:** Tabela mostra as 20 primeiras leituras com ID, Veículo, PPM, Status e Data/Hora
- **Analisar Estatísticas:** Cards no topo mostram "Total de Leituras", "Total de Bloqueios", "Média PPM" e "Máximo PPM"

---

## Gerenciando Seu Website

### Management UI Panels

Acesse o painel de gerenciamento através do ícone no canto superior direito:

**Settings Panel:**
- **General:** Configure o título do website (VITE_APP_TITLE) e logo (VITE_APP_LOGO)
- **Secrets:** Gerencie variáveis de ambiente (não necessário para funcionamento básico)
- **Database:** Acesse a interface CRUD do banco de dados para adicionar/editar dados manualmente

**Dashboard Panel:**
- Monitore estatísticas de uso do website
- Visualize analytics (visitantes únicos, page views)

**Preview Panel:**
- Veja uma prévia ao vivo do seu website
- Teste funcionalidades antes de publicar

### Adicionando Dados Manualmente

Você pode adicionar motoristas, veículos e leituras através do painel Database:

1. Abra "Management UI" → "Database"
2. Selecione a tabela desejada (motoristas, veiculos, leiturasSensor)
3. Clique em "Insert" para adicionar novos registros
4. Preencha os campos obrigatórios

---

## Next Steps

**Comece agora:** Fale com Manus AI anytime para solicitar mudanças ou adicionar novas funcionalidades.

**Próximas ações recomendadas:**
- Adicione seus primeiros veículos e motoristas através do Management UI
- Inicie o script de simulação (`node mockData.mjs`) para gerar dados de teste
- Explore os gráficos e relatórios para familiarizar-se com as visualizações
- Configure alertas e notificações conforme suas necessidades

**Dica:** O sistema está pronto para integração com sensores ESP32 reais. Quando tiver o hardware, basta apontar para a API `/api/trpc/leituras.criar`.

---

**Versão:** 1.0.0  
**Última atualização:** Novembro 2025
