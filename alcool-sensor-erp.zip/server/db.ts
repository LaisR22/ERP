import { eq, desc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, motoristas, veiculos, leiturasSensor, eventos, InsertLeituraSensor, InsertMotorista, InsertVeiculo, InsertEvento } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ LEITURAS SENSOR ============
export async function criarLeituraSensor(leitura: InsertLeituraSensor) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(leiturasSensor).values(leitura);
}

export async function obterTodasAsLeituras(limite: number = 100, offset: number = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db
    .select()
    .from(leiturasSensor)
    .orderBy(desc(leiturasSensor.dataHora))
    .limit(limite)
    .offset(offset);
}

export async function obterLeiturasPorVeiculo(veiculoId: number, limite: number = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db
    .select()
    .from(leiturasSensor)
    .where(eq(leiturasSensor.veiculoId, veiculoId))
    .orderBy(desc(leiturasSensor.dataHora))
    .limit(limite);
}

export async function obterUltimaLeituraPorVeiculo(veiculoId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const resultado = await db
    .select()
    .from(leiturasSensor)
    .where(eq(leiturasSensor.veiculoId, veiculoId))
    .orderBy(desc(leiturasSensor.dataHora))
    .limit(1);
  
  return resultado.length > 0 ? resultado[0] : null;
}

// ============ MOTORISTAS ============
export async function criarMotorista(motorista: InsertMotorista) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(motoristas).values(motorista);
}

export async function obterTodosOsMotoristas() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(motoristas).where(eq(motoristas.ativo, true));
}

export async function obterMotoristaById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const resultado = await db.select().from(motoristas).where(eq(motoristas.id, id)).limit(1);
  return resultado.length > 0 ? resultado[0] : null;
}

// ============ VEÍCULOS ============
export async function criarVeiculo(veiculo: InsertVeiculo) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(veiculos).values(veiculo);
}

export async function obterTodosOsVeiculos() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(veiculos).where(eq(veiculos.ativo, true));
}

export async function obterVeiculoById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const resultado = await db.select().from(veiculos).where(eq(veiculos.id, id)).limit(1);
  return resultado.length > 0 ? resultado[0] : null;
}

// ============ EVENTOS ============
export async function criarEvento(evento: InsertEvento) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(eventos).values(evento);
}

export async function obterEventosPorVeiculo(veiculoId: number, limite: number = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db
    .select()
    .from(eventos)
    .where(eq(eventos.veiculoId, veiculoId))
    .orderBy(desc(eventos.dataHora))
    .limit(limite);
}

// ============ ESTATÍSTICAS ============
export async function obterEstatisticas() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const totalLeituras = await db.select({ count: sql<number>`COUNT(*)` }).from(leiturasSensor);
  const totalBloqueios = await db.select({ count: sql<number>`COUNT(*)` }).from(leiturasSensor).where(eq(leiturasSensor.bloqueado, true));
  const mediasPpm = await db.select({ media: sql<number>`AVG(ppm)` }).from(leiturasSensor);
  const totalVeiculos = await db.select({ count: sql<number>`COUNT(*)` }).from(veiculos).where(eq(veiculos.ativo, true));
  const totalMotoristas = await db.select({ count: sql<number>`COUNT(*)` }).from(motoristas).where(eq(motoristas.ativo, true));
  
  return {
    totalLeituras: (totalLeituras[0]?.count as number) || 0,
    totalBloqueios: (totalBloqueios[0]?.count as number) || 0,
    mediaPpm: parseFloat((mediasPpm[0]?.media as number)?.toString() || '0'),
    totalVeiculos: (totalVeiculos[0]?.count as number) || 0,
    totalMotoristas: (totalMotoristas[0]?.count as number) || 0,
  };
}
