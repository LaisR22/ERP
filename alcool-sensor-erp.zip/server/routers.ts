import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  criarLeituraSensor,
  obterTodasAsLeituras,
  obterLeiturasPorVeiculo,
  obterUltimaLeituraPorVeiculo,
  criarMotorista,
  obterTodosOsMotoristas,
  obterMotoristaById,
  criarVeiculo,
  obterTodosOsVeiculos,
  obterVeiculoById,
  criarEvento,
  obterEventosPorVeiculo,
  obterEstatisticas,
} from "./db";

const LIMITE_PPM = 300; // Limite de bloqueio: 300 ppm

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ LEITURAS SENSOR ============
  leituras: router({
    // Criar nova leitura (receber dados do sensor)
    criar: publicProcedure
      .input(
        z.object({
          veiculoId: z.number(),
          motoristaId: z.number().optional(),
          ppm: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        // Determinar status baseado no PPM
        let status: "LIBERADO" | "ALERTA" | "BLOQUEADO";
        let bloqueado = false;

        if (input.ppm > LIMITE_PPM) {
          status = "BLOQUEADO";
          bloqueado = true;
        } else if (input.ppm > LIMITE_PPM * 0.7) {
          status = "ALERTA";
        } else {
          status = "LIBERADO";
        }

        // Criar leitura
        const leitura = await criarLeituraSensor({
          veiculoId: input.veiculoId,
          motoristaId: input.motoristaId,
          ppm: input.ppm,
          status,
          bloqueado,
          dataHora: new Date(),
        });

        // Se foi bloqueado, criar evento
        if (bloqueado) {
          await criarEvento({
            veiculoId: input.veiculoId,
            motoristaId: input.motoristaId,
            tipo: "BLOQUEIO",
            descricao: `Bloqueio detectado: ${input.ppm} ppm`,
            ppm: input.ppm,
            dataHora: new Date(),
          });
        } else if (status === "ALERTA") {
          await criarEvento({
            veiculoId: input.veiculoId,
            motoristaId: input.motoristaId,
            tipo: "ALERTA",
            descricao: `Alerta: ${input.ppm} ppm`,
            ppm: input.ppm,
            dataHora: new Date(),
          });
        }

        return { sucesso: true, leitura };
      }),

    // Listar todas as leituras
    listar: publicProcedure
      .input(
        z.object({
          limite: z.number().default(100),
          offset: z.number().default(0),
        })
      )
      .query(async ({ input }) => {
        return await obterTodasAsLeituras(input.limite, input.offset);
      }),

    // Listar leituras por veículo
    porVeiculo: publicProcedure
      .input(
        z.object({
          veiculoId: z.number(),
          limite: z.number().default(50),
        })
      )
      .query(async ({ input }) => {
        return await obterLeiturasPorVeiculo(input.veiculoId, input.limite);
      }),

    // Obter última leitura de um veículo
    ultimaPorVeiculo: publicProcedure
      .input(z.object({ veiculoId: z.number() }))
      .query(async ({ input }) => {
        return await obterUltimaLeituraPorVeiculo(input.veiculoId);
      }),
  }),

  // ============ MOTORISTAS ============
  motoristas: router({
    // Criar novo motorista
    criar: protectedProcedure
      .input(
        z.object({
          nome: z.string(),
          cpf: z.string(),
          email: z.string().optional(),
          telefone: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await criarMotorista({
          nome: input.nome,
          cpf: input.cpf,
          email: input.email,
          telefone: input.telefone,
          ativo: true,
        });
      }),

    // Listar todos os motoristas
    listar: publicProcedure.query(async () => {
      return await obterTodosOsMotoristas();
    }),

    // Obter motorista por ID
    porId: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await obterMotoristaById(input.id);
      }),
  }),

  // ============ VEÍCULOS ============
  veiculos: router({
    // Criar novo veículo
    criar: protectedProcedure
      .input(
        z.object({
          placa: z.string(),
          marca: z.string().optional(),
          modelo: z.string().optional(),
          ano: z.number().optional(),
          cor: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await criarVeiculo({
          placa: input.placa,
          marca: input.marca,
          modelo: input.modelo,
          ano: input.ano,
          cor: input.cor,
          ativo: true,
        });
      }),

    // Listar todos os veículos
    listar: publicProcedure.query(async () => {
      return await obterTodosOsVeiculos();
    }),

    // Obter veículo por ID
    porId: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await obterVeiculoById(input.id);
      }),
  }),

  // ============ EVENTOS ============
  eventos: router({
    // Listar eventos por veículo
    porVeiculo: publicProcedure
      .input(
        z.object({
          veiculoId: z.number(),
          limite: z.number().default(50),
        })
      )
      .query(async ({ input }) => {
        return await obterEventosPorVeiculo(input.veiculoId, input.limite);
      }),
  }),

  // ============ ESTATÍSTICAS ============
  estatisticas: router({
    // Obter estatísticas gerais
    geral: publicProcedure.query(async () => {
      return await obterEstatisticas();
    }),
  }),
});

export type AppRouter = typeof appRouter;
