# ERP/Dashboard - Sensor de Álcool no Volante - TODO

## Banco de Dados e Schema
- [x] Criar tabelas: Motorista, Veículo, LeituraSensor, Evento
- [x] Configurar relacionamentos entre tabelas
- [x] Definir limite de álcool (300 ppm = bloqueio)
- [x] Executar migrations com `pnpm db:push`

## Backend - API REST (tRPC)
- [x] Criar estrutura de procedures tRPC
- [x] Implementar funções de banco de dados para CRUD
- [x] Criar procedure `leituras.criar` - receber dados do sensor
- [x] Criar procedure `leituras.listar` - listar todas as leituras
- [x] Criar procedure `leituras.porVeiculo` - filtrar por veículo
- [x] Criar procedure `estatisticas.geral` - retornar métricas
- [x] Implementar script `mockData.mjs` para simular dados do ESP32
- [x] Testar procedures com tRPC

## Frontend - Dashboard (React/TailwindCSS)
- [x] Configurar estrutura de pastas (components, pages, services)
- [x] Criar cliente tRPC para comunicação com backend
- [x] Implementar página `/dashboard` com visão geral
- [x] Implementar página `/veiculos` com tabela de veículos
- [x] Implementar página `/motoristas` com histórico de condutores
- [x] Criar componentes de cards de resumo
- [x] Criar tabelas com últimas leituras
- [x] Criar gráficos com Recharts
- [x] Implementar atualização automática (useQuery)
- [x] Estilizar com Tailwind (modo claro e responsivo)

## Integração Backend + Frontend
- [x] Conectar React com API usando tRPC
- [x] Implementar feedback visual (Verde=seguro, Amarelo=alerta, Vermelho=bloqueio)
- [x] Criar filtros por veículo
- [x] Implementar filtro por período
- [x] Adicionar polling para simulação de tempo real
- [x] Testar integração completa

## Relatórios e Estatísticas
- [x] Criar procedure `estatisticas.geral` no backend
- [x] Exibir estatísticas no Dashboard (cards)
- [x] Implementar exportação CSV (página Relatórios)
- [x] Criar gráfico histórico por veículo
- [x] Implementar página de Relatórios com filtros

## Documentação e Entrega
- [x] Criar `README.md` com descrição completa
- [x] Documentar procedures da API
- [x] Adicionar comentários no código
- [x] Estruturar projeto com organização clara
- [x] Preparar para deploy

## Testes
- [x] Testar envio de leituras via tRPC
- [x] Testar recuperação de leituras com queries
- [x] Testar filtros por veículo e período
- [x] Testar atualização automática do Dashboard
- [x] Testar feedback visual (cores de status)
- [x] Testar script de simulação
