# 🚗 ERP/Dashboard - Sensor de Álcool no Volante

Sistema completo de monitoramento em tempo real de níveis de álcool em veículos, desenvolvido com **Node.js + Express + React + TailwindCSS**.

## 📋 Visão Geral

Este projeto implementa um **ERP (Enterprise Resource Planning)** para gerenciar e monitorar dados enviados por sensores de álcool instalados em veículos. O sistema simula a integração com um **ESP32** e fornece um dashboard interativo para visualizar leituras, gerenciar motoristas e veículos, além de gerar relatórios detalhados.

### 🎯 Objetivos

- **Monitoramento em Tempo Real**: Acompanhe os níveis de álcool de seus veículos com atualização automática
- **Limite de Segurança**: Bloqueio automático quando o nível ultrapassa 300 ppm
- **Gerenciamento Completo**: Cadastre e gerencie motoristas, veículos e eventos
- **Relatórios Detalhados**: Exporte dados e visualize estatísticas

## 🛠️ Stack Tecnológico

### Backend
- **Node.js** + **Express** - Framework web
- **tRPC** - RPC framework com type-safety end-to-end
- **Drizzle ORM** - Query builder e ORM
- **MySQL** - Banco de dados relacional
- **TypeScript** - Tipagem estática

### Frontend
- **React 19** - Biblioteca de UI
- **TypeScript** - Tipagem estática
- **TailwindCSS 4** - Framework CSS
- **Recharts** - Biblioteca de gráficos
- **shadcn/ui** - Componentes de UI
- **Wouter** - Router minimalista

## 📁 Estrutura do Projeto

```
alcool-sensor-erp/
├── client/                          # Frontend React
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.tsx            # Página inicial
│   │   │   ├── Dashboard.tsx       # Dashboard principal
│   │   │   ├── Veiculos.tsx        # Gerenciamento de veículos
│   │   │   ├── Motoristas.tsx      # Gerenciamento de motoristas
│   │   │   ├── Relatorios.tsx      # Relatórios e estatísticas
│   │   │   └── NotFound.tsx        # Página 404
│   │   ├── components/             # Componentes reutilizáveis
│   │   ├── lib/trpc.ts             # Cliente tRPC
│   │   ├── App.tsx                 # Roteamento principal
│   │   └── index.css               # Estilos globais
│   └── index.html                  # HTML base
├── server/                          # Backend Node.js
│   ├── db.ts                       # Funções de banco de dados
│   ├── routers.ts                  # Procedures tRPC
│   └── _core/                      # Framework plumbing
├── drizzle/
│   ├── schema.ts                   # Schema do banco de dados
│   └── migrations/                 # Arquivos de migração
├── mockData.mjs                    # Script de simulação de sensor
├── package.json                    # Dependências
└── README.md                       # Este arquivo
```

## 🚀 Como Iniciar

### Pré-requisitos

- Node.js 18+ instalado
- npm ou pnpm como gerenciador de pacotes
- Banco de dados MySQL configurado

### Instalação

1. **Clone o repositório** (ou extraia os arquivos)

```bash
cd alcool-sensor-erp
```

2. **Instale as dependências**

```bash
pnpm install
```

3. **Configure o banco de dados**

```bash
pnpm db:push
```

4. **Inicie o servidor de desenvolvimento**

```bash
pnpm dev
```

O servidor estará disponível em `http://localhost:3000`

## 📊 Funcionalidades Principais

### 1. Dashboard
- **Cards de Resumo**: Total de leituras, bloqueios, média PPM, veículos ativos
- **Gráfico de Histórico**: Visualize a evolução dos níveis de álcool ao longo do tempo
- **Gráfico de Distribuição**: Veja a proporção de leituras por status
- **Últimas Leituras**: Tabela com as 10 leituras mais recentes

### 2. Gerenciamento de Veículos
- Cadastre novos veículos com placa, marca, modelo, ano e cor
- Visualize lista completa de veículos ativos
- Acompanhe o status de cada veículo em tempo real
- Acesse detalhes e histórico de leituras por veículo

### 3. Gerenciamento de Motoristas
- Cadastre motoristas com nome, CPF, email e telefone
- Visualize lista de motoristas ativos
- Acompanhe histórico de leituras por motorista
- Estatísticas de motoristas com email cadastrado

### 4. Relatórios e Estatísticas
- **Filtros Avançados**: Filtre leituras por veículo e período
- **Gráficos Históricos**: Visualize tendências de PPM
- **Distribuição de Status**: Veja proporção de bloqueios, alertas e liberações
- **Exportação CSV**: Baixe dados em formato CSV para análise externa
- **Estatísticas Detalhadas**: Total, média, máximo e mínimo de PPM

### 5. Sistema de Alertas
- **Verde (Liberado)**: PPM 0-210 ppm - Seguro
- **Amarelo (Alerta)**: PPM 210-300 ppm - Atenção
- **Vermelho (Bloqueado)**: PPM > 300 ppm - Bloqueio automático

## 🔌 API REST (tRPC)

### Endpoints Disponíveis

#### Leituras
- `POST /api/trpc/leituras.criar` - Criar nova leitura
- `GET /api/trpc/leituras.listar` - Listar todas as leituras
- `GET /api/trpc/leituras.porVeiculo` - Leituras por veículo
- `GET /api/trpc/leituras.ultimaPorVeiculo` - Última leitura de um veículo

#### Motoristas
- `POST /api/trpc/motoristas.criar` - Criar novo motorista
- `GET /api/trpc/motoristas.listar` - Listar motoristas
- `GET /api/trpc/motoristas.porId` - Obter motorista por ID

#### Veículos
- `POST /api/trpc/veiculos.criar` - Criar novo veículo
- `GET /api/trpc/veiculos.listar` - Listar veículos
- `GET /api/trpc/veiculos.porId` - Obter veículo por ID

#### Eventos
- `GET /api/trpc/eventos.porVeiculo` - Eventos de um veículo

#### Estatísticas
- `GET /api/trpc/estatisticas.geral` - Estatísticas gerais do sistema

## 📡 Simulação de Sensor ESP32

O projeto inclui um script `mockData.mjs` que simula o envio de dados de um sensor ESP32.

### Como Usar

1. **Inicie o servidor de desenvolvimento** (em outro terminal)

```bash
pnpm dev
```

2. **Execute o script de simulação**

```bash
node mockData.mjs
```

O script enviará leituras simuladas a cada 10 segundos com os seguintes padrões:
- **70% de chance**: LIBERADO (0-210 ppm)
- **20% de chance**: ALERTA (210-300 ppm)
- **10% de chance**: BLOQUEADO (300+ ppm)

### Configuração

Você pode customizar o comportamento do script através de variáveis de ambiente:

```bash
# Alterar URL da API
API_URL=http://localhost:3000/api/trpc node mockData.mjs

# Alterar intervalo de envio (em milissegundos)
INTERVALO=5000 node mockData.mjs
```

## 📊 Schema do Banco de Dados

### Tabela: users
Usuários do sistema (autenticação Manus OAuth)

### Tabela: motoristas
```sql
- id (int, PK)
- nome (varchar)
- cpf (varchar, UNIQUE)
- email (varchar)
- telefone (varchar)
- ativo (boolean)
- criadoEm (timestamp)
- atualizadoEm (timestamp)
```

### Tabela: veiculos
```sql
- id (int, PK)
- placa (varchar, UNIQUE)
- marca (varchar)
- modelo (varchar)
- ano (int)
- cor (varchar)
- ativo (boolean)
- criadoEm (timestamp)
- atualizadoEm (timestamp)
```

### Tabela: leiturasSensor
```sql
- id (int, PK)
- veiculoId (int, FK)
- motoristaId (int, FK)
- ppm (float)
- status (enum: LIBERADO, ALERTA, BLOQUEADO)
- bloqueado (boolean)
- dataHora (timestamp)
- criadoEm (timestamp)
```

### Tabela: eventos
```sql
- id (int, PK)
- veiculoId (int, FK)
- motoristaId (int, FK)
- tipo (enum: BLOQUEIO, ALERTA, DESBLOQUEIO)
- descricao (text)
- ppm (float)
- dataHora (timestamp)
- criadoEm (timestamp)
```

## 🔐 Autenticação

O sistema utiliza **Manus OAuth** para autenticação. Todos os usuários devem fazer login através do portal Manus antes de acessar o dashboard.

### Rotas Protegidas
- `/dashboard` - Requer autenticação
- `/veiculos` - Requer autenticação
- `/motoristas` - Requer autenticação
- `/relatorios` - Requer autenticação

### Rotas Públicas
- `/` - Home page (sem autenticação)

## 🧪 Testes

### Testar Backend
```bash
# Verificar se a API está respondendo
curl http://localhost:3000/api/trpc/estatisticas.geral

# Criar nova leitura
curl -X POST http://localhost:3000/api/trpc/leituras.criar \
  -H "Content-Type: application/json" \
  -d '{"json":{"veiculoId":1,"ppm":150}}'
```

### Testar Frontend
1. Acesse `http://localhost:3000`
2. Faça login com sua conta Manus
3. Navegue pelo Dashboard, Veículos, Motoristas e Relatórios
4. Verifique se os dados estão sendo exibidos corretamente

## 📈 Performance

- **Atualização Automática**: Dashboard atualiza a cada 5 segundos
- **Paginação**: Leituras carregadas com limite de 100 registros
- **Gráficos Otimizados**: Recharts renderiza apenas os últimos 30 registros
- **Caching**: tRPC implementa caching automático de queries

## 🐛 Troubleshooting

### Erro: "Database not available"
- Verifique se o MySQL está rodando
- Confirme a variável de ambiente `DATABASE_URL`
- Execute `pnpm db:push` para criar as tabelas

### Erro: "Cannot find module"
- Execute `pnpm install` novamente
- Limpe o cache: `pnpm install --force`

### Dashboard não carrega dados
- Verifique se o servidor está rodando (`pnpm dev`)
- Abra o console do navegador (F12) para ver erros
- Verifique a aba Network para ver requisições tRPC

### Script de simulação não envia dados
- Verifique se o servidor está rodando
- Confirme a URL da API com `echo $API_URL`
- Veja os logs do servidor para erros

## 📝 Commits Recomendados

```bash
# Inicialização do projeto
git commit -m "feat: init ERP sensor de álcool"

# Schema do banco de dados
git commit -m "feat: add database schema (motoristas, veículos, leituras, eventos)"

# Backend API
git commit -m "feat: implement tRPC routers for sensor data"

# Frontend
git commit -m "feat: add dashboard, veículos, motoristas pages"

# Simulação
git commit -m "feat: add ESP32 sensor simulation script"

# Documentação
git commit -m "docs: add comprehensive README"
```

## 🚀 Deployment

### Opções de Hospedagem

**Backend:**
- [Render](https://render.com) - Deploy automático do Node.js
- [Railway](https://railway.app) - Plataforma moderna de deploy
- [Heroku](https://www.heroku.com) - Clássico PaaS

**Frontend:**
- [Vercel](https://vercel.com) - Otimizado para Next.js/React
- [Netlify](https://www.netlify.com) - Deploy contínuo
- [GitHub Pages](https://pages.github.com) - Hospedagem estática

### Variáveis de Ambiente para Produção

```env
# Backend
DATABASE_URL=mysql://user:password@host:port/database
NODE_ENV=production

# Frontend
VITE_API_URL=https://api.seu-dominio.com
```

## 📚 Documentação Adicional

- [Drizzle ORM Docs](https://orm.drizzle.team)
- [tRPC Documentation](https://trpc.io)
- [React Documentation](https://react.dev)
- [TailwindCSS Documentation](https://tailwindcss.com)
- [Recharts Documentation](https://recharts.org)

## 📄 Licença

Este projeto é fornecido como exemplo educacional.

## 👨‍💻 Autor

Desenvolvido com ❤️ por Manus AI

---

**Última atualização**: Novembro 2025

Para dúvidas ou sugestões, abra uma issue no repositório!
