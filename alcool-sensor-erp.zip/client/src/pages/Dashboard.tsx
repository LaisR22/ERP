import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, CheckCircle, XCircle, TrendingUp } from "lucide-react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function Dashboard() {
  const [leituras, setLeituras] = useState<any[]>([]);
  const [ultimasLeituras, setUltimasLeituras] = useState<any[]>([]);

  // Buscar estatísticas
  const { data: stats, isLoading: statsLoading } = trpc.estatisticas.geral.useQuery();

  // Buscar leituras recentes
  const { data: leiturasData, isLoading: leiturasLoading } = trpc.leituras.listar.useQuery({
    limite: 50,
    offset: 0,
  });

  // Atualizar dados a cada 5 segundos
  useEffect(() => {
    if (leiturasData) {
      setUltimasLeituras(leiturasData.slice(0, 10));
      setLeituras(leiturasData);
    }
  }, [leiturasData]);

  // Preparar dados para gráfico
  const dadosGrafico = leituras.slice(0, 20).reverse().map((l, idx) => ({
    tempo: `${idx}min`,
    ppm: l.ppm,
    status: l.status,
  }));

  // Preparar dados para gráfico de status
  const statusCounts = {
    LIBERADO: leituras.filter((l) => l.status === "LIBERADO").length,
    ALERTA: leituras.filter((l) => l.status === "ALERTA").length,
    BLOQUEADO: leituras.filter((l) => l.status === "BLOQUEADO").length,
  };

  const dadosStatus = [
    { name: "Liberado", value: statusCounts.LIBERADO, fill: "#22c55e" },
    { name: "Alerta", value: statusCounts.ALERTA, fill: "#eab308" },
    { name: "Bloqueado", value: statusCounts.BLOQUEADO, fill: "#ef4444" },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "LIBERADO":
        return "text-green-600";
      case "ALERTA":
        return "text-yellow-600";
      case "BLOQUEADO":
        return "text-red-600";
      default:
        return "text-gray-600";
    }
  };

  const getStatusBgColor = (status: string) => {
    switch (status) {
      case "LIBERADO":
        return "bg-green-50";
      case "ALERTA":
        return "bg-yellow-50";
      case "BLOQUEADO":
        return "bg-red-50";
      default:
        return "bg-gray-50";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-gray-500 mt-2">Monitoramento em tempo real do sensor de álcool</p>
      </div>

      {/* Cards de Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total de Leituras */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Leituras</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsLoading ? "..." : stats?.totalLeituras || 0}</div>
            <p className="text-xs text-gray-500">Leituras registradas</p>
          </CardContent>
        </Card>

        {/* Total de Bloqueios */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Bloqueios</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{statsLoading ? "..." : stats?.totalBloqueios || 0}</div>
            <p className="text-xs text-gray-500">Acima de 300 ppm</p>
          </CardContent>
        </Card>

        {/* Média PPM */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Média PPM</CardTitle>
            <AlertCircle className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsLoading ? "..." : stats?.mediaPpm.toFixed(1) || 0}</div>
            <p className="text-xs text-gray-500">Nível médio de álcool</p>
          </CardContent>
        </Card>

        {/* Veículos Ativos */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Veículos Ativos</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statsLoading ? "..." : stats?.totalVeiculos || 0}</div>
            <p className="text-xs text-gray-500">Em monitoramento</p>
          </CardContent>
        </Card>
      </div>

      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Gráfico de Leituras */}
        <Card>
          <CardHeader>
            <CardTitle>Histórico de Leituras (PPM)</CardTitle>
            <CardDescription>Últimas 20 leituras</CardDescription>
          </CardHeader>
          <CardContent>
            {dadosGrafico.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={dadosGrafico}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="tempo" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="ppm" stroke="#3b82f6" name="PPM" />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-gray-500">
                Sem dados disponíveis
              </div>
            )}
          </CardContent>
        </Card>

        {/* Gráfico de Status */}
        <Card>
          <CardHeader>
            <CardTitle>Distribuição de Status</CardTitle>
            <CardDescription>Leituras por status</CardDescription>
          </CardHeader>
          <CardContent>
            {dadosStatus.some((d) => d.value > 0) ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={dadosStatus}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-gray-500">
                Sem dados disponíveis
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Últimas Leituras */}
      <Card>
        <CardHeader>
          <CardTitle>Últimas Leituras</CardTitle>
          <CardDescription>10 leituras mais recentes</CardDescription>
        </CardHeader>
        <CardContent>
          {leiturasLoading ? (
            <div className="text-center py-8 text-gray-500">Carregando...</div>
          ) : ultimasLeituras.length > 0 ? (
            <div className="space-y-3">
              {ultimasLeituras.map((leitura) => (
                <div
                  key={leitura.id}
                  className={`flex items-center justify-between p-3 rounded-lg ${getStatusBgColor(
                    leitura.status
                  )}`}
                >
                  <div>
                    <p className="font-medium">Veículo ID: {leitura.veiculoId}</p>
                    <p className="text-sm text-gray-600">
                      {new Date(leitura.dataHora).toLocaleString("pt-BR")}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold text-lg ${getStatusColor(leitura.status)}`}>
                      {leitura.ppm.toFixed(1)} ppm
                    </p>
                    <p className={`text-sm font-medium ${getStatusColor(leitura.status)}`}>
                      {leitura.status}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">Nenhuma leitura disponível</div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
