import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, CheckCircle, XCircle, Plus } from "lucide-react";

export default function Veiculos() {
  const [veiculos, setVeiculos] = useState<any[]>([]);
  const [ultimasLeituras, setUltimasLeituras] = useState<{ [key: number]: any }>({});

  // Buscar veículos
  const { data: veiculosData, isLoading: veiculosLoading } = trpc.veiculos.listar.useQuery();

  // Buscar última leitura para cada veículo
  useEffect(() => {
    if (veiculosData) {
      setVeiculos(veiculosData);
      veiculosData.forEach((v) => {
        trpc.leituras.ultimaPorVeiculo.useQuery({ veiculoId: v.id });
      });
    }
  }, [veiculosData]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "LIBERADO":
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case "ALERTA":
        return <AlertCircle className="h-5 w-5 text-yellow-600" />;
      case "BLOQUEADO":
        return <XCircle className="h-5 w-5 text-red-600" />;
      default:
        return null;
    }
  };

  const getStatusBadge = (status: string) => {
    const baseClass = "px-3 py-1 rounded-full text-sm font-medium";
    switch (status) {
      case "LIBERADO":
        return `${baseClass} bg-green-100 text-green-800`;
      case "ALERTA":
        return `${baseClass} bg-yellow-100 text-yellow-800`;
      case "BLOQUEADO":
        return `${baseClass} bg-red-100 text-red-800`;
      default:
        return `${baseClass} bg-gray-100 text-gray-800`;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Veículos</h1>
          <p className="text-gray-500 mt-2">Gerenciamento de veículos monitorados</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Novo Veículo
        </Button>
      </div>

      {/* Tabela de Veículos */}
      <Card>
        <CardHeader>
          <CardTitle>Veículos Cadastrados</CardTitle>
          <CardDescription>Lista de todos os veículos em monitoramento</CardDescription>
        </CardHeader>
        <CardContent>
          {veiculosLoading ? (
            <div className="text-center py-8 text-gray-500">Carregando veículos...</div>
          ) : veiculos.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Placa</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Marca/Modelo</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Ano</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Cor</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Última Leitura</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {veiculos.map((veiculo) => (
                    <tr key={veiculo.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-4 font-semibold">{veiculo.placa}</td>
                      <td className="py-3 px-4">
                        {veiculo.marca} {veiculo.modelo}
                      </td>
                      <td className="py-3 px-4">{veiculo.ano || "-"}</td>
                      <td className="py-3 px-4">{veiculo.cor || "-"}</td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center gap-2">
                          <div className="h-3 w-3 rounded-full bg-green-600"></div>
                          <span className="text-sm">Ativo</span>
                        </span>
                      </td>
                      <td className="py-3 px-4 text-sm text-gray-600">
                        {new Date(veiculo.atualizadoEm).toLocaleString("pt-BR")}
                      </td>
                      <td className="py-3 px-4">
                        <Button variant="outline" size="sm">
                          Ver Detalhes
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">Nenhum veículo cadastrado</div>
          )}
        </CardContent>
      </Card>

      {/* Resumo de Veículos */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total de Veículos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{veiculos.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Veículos Ativos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {veiculos.filter((v) => v.ativo).length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Última Atualização</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-sm text-gray-600">
              {veiculos.length > 0
                ? new Date(veiculos[0].atualizadoEm).toLocaleString("pt-BR")
                : "-"}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
