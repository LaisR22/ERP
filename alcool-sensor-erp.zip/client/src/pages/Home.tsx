import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, Users, Gauge, AlertTriangle } from "lucide-react";
import { Link } from "wouter";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {APP_LOGO && <img src={APP_LOGO} alt={APP_TITLE} className="h-8 w-8" />}
            <h1 className="text-2xl font-bold text-gray-900">{APP_TITLE}</h1>
          </div>
          <div>
            {isAuthenticated ? (
              <div className="flex items-center gap-4">
                <span className="text-sm text-gray-600">Bem-vindo, {user?.name}</span>
                <Link href="/dashboard">
                  <Button>Ir para Dashboard</Button>
                </Link>
              </div>
            ) : (
              <a href={getLoginUrl()}>
                <Button>Fazer Login</Button>
              </a>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {isAuthenticated ? (
          <>
            {/* Welcome Section */}
            <div className="mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Bem-vindo ao ERP de Monitoramento de Álcool
              </h2>
              <p className="text-xl text-gray-600 mb-8">
                Sistema completo para monitoramento em tempo real de níveis de álcool em veículos
              </p>

              <Link href="/dashboard">
                <Button size="lg" className="gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Acessar Dashboard
                </Button>
              </Link>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Link href="/dashboard">
                <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5 text-blue-600" />
                      Dashboard
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">
                      Visualize estatísticas em tempo real e gráficos de monitoramento
                    </p>
                  </CardContent>
                </Card>
              </Link>

              <Link href="/veiculos">
                <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Gauge className="h-5 w-5 text-green-600" />
                      Veículos
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">
                      Gerencie veículos e acompanhe suas leituras de álcool
                    </p>
                  </CardContent>
                </Card>
              </Link>

              <Link href="/motoristas">
                <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-purple-600" />
                      Motoristas
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">
                      Cadastre e acompanhe o histórico de motoristas
                    </p>
                  </CardContent>
                </Card>
              </Link>

              <Card className="hover:shadow-lg transition-shadow h-full">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                    Alertas
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Receba notificações de bloqueios e alertas em tempo real
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Stats Section */}
            <div className="mt-12 bg-white rounded-lg shadow-md p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Sobre o Sistema</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">Monitoramento em Tempo Real</h4>
                  <p className="text-gray-600">
                    Acompanhe os níveis de álcool de seus veículos com atualização automática a cada 5 segundos
                  </p>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">Limite de Segurança</h4>
                  <p className="text-gray-600">
                    Bloqueio automático quando o nível de álcool ultrapassa 300 ppm, com alertas em 210 ppm
                  </p>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">Relatórios Detalhados</h4>
                  <p className="text-gray-600">
                    Gere relatórios completos com histórico de leituras, eventos e estatísticas
                  </p>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="text-center py-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Sistema de Monitoramento de Álcool no Volante
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Faça login para acessar o dashboard e gerenciar seus veículos
            </p>
            <a href={getLoginUrl()}>
              <Button size="lg">Fazer Login</Button>
            </a>
          </div>
        )}
      </main>
    </div>
  );
}
