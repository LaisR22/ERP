import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Mail, Phone } from "lucide-react";

export default function Motoristas() {
  const [motoristas, setMotoristas] = useState<any[]>([]);

  // Buscar motoristas
  const { data: motoristasData, isLoading: motoristasLoading } = trpc.motoristas.listar.useQuery();

  useEffect(() => {
    if (motoristasData) {
      setMotoristas(motoristasData);
    }
  }, [motoristasData]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Motoristas</h1>
          <p className="text-gray-500 mt-2">Gerenciamento de condutores</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Novo Motorista
        </Button>
      </div>

      {/* Tabela de Motoristas */}
      <Card>
        <CardHeader>
          <CardTitle>Motoristas Cadastrados</CardTitle>
          <CardDescription>Lista de todos os motoristas registrados no sistema</CardDescription>
        </CardHeader>
        <CardContent>
          {motoristasLoading ? (
            <div className="text-center py-8 text-gray-500">Carregando motoristas...</div>
          ) : motoristas.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Nome</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">CPF</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Email</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Telefone</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Cadastro</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-700">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {motoristas.map((motorista) => (
                    <tr key={motorista.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-4 font-semibold">{motorista.nome}</td>
                      <td className="py-3 px-4 font-mono text-sm">
                        {motorista.cpf.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, "$1.$2.$3-$4")}
                      </td>
                      <td className="py-3 px-4">
                        {motorista.email ? (
                          <div className="flex items-center gap-2 text-sm">
                            <Mail className="h-4 w-4 text-gray-400" />
                            {motorista.email}
                          </div>
                        ) : (
                          <span className="text-gray-400">-</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        {motorista.telefone ? (
                          <div className="flex items-center gap-2 text-sm">
                            <Phone className="h-4 w-4 text-gray-400" />
                            {motorista.telefone}
                          </div>
                        ) : (
                          <span className="text-gray-400">-</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center gap-2">
                          <div className="h-3 w-3 rounded-full bg-green-600"></div>
                          <span className="text-sm">Ativo</span>
                        </span>
                      </td>
                      <td className="py-3 px-4 text-sm text-gray-600">
                        {new Date(motorista.criadoEm).toLocaleDateString("pt-BR")}
                      </td>
                      <td className="py-3 px-4">
                        <Button variant="outline" size="sm">
                          Ver Histórico
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">Nenhum motorista cadastrado</div>
          )}
        </CardContent>
      </Card>

      {/* Resumo de Motoristas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total de Motoristas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{motoristas.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Motoristas Ativos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {motoristas.filter((m) => m.ativo).length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Com Email</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {motoristas.filter((m) => m.email).length}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
